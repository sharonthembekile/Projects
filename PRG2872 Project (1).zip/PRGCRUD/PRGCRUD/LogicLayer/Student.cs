﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRGCRUD.DataLayer;
using PRGCRUD.PresentationLayer;

namespace PRGCRUD.LogicLayer
{
    internal class Student
    {
        internal string StudentNumber;
        string name, surname, gender, phone, address, moduleCodes; 
        int studentNum;
        DateTime dateOfBirth;
        PictureBox pic;

        public Student()
        {
        }

        public Student(string name, string surname, string gender, string phone, string address, string moduleCodes, int studentNum, DateTime dateOfBirth, PictureBox pic)
        {
            this.name = name;
            this.surname = surname;
            this.gender = gender;
            this.phone = phone;
            this.address = address;
            this.moduleCodes = moduleCodes;
            this.studentNum = studentNum;
            this.dateOfBirth = dateOfBirth;
            this.pic = pic;
        }
         
        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Address { get => address; set => address = value; }
        public string ModuleCodes { get => moduleCodes; set => moduleCodes = value; }
        public int StudentNum { get => studentNum; set => studentNum = value; }
        public DateTime DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        public PictureBox Pic { get => pic; set => pic = value; }
        public object StudentName { get; internal set; }
        public object StudentSurname { get; internal set; }
        public object StudentImage { get; internal set; }

        /*public static implicit operator Student(Student v)
        {
            throw new NotImplementedException();
        }*/
    }
}
