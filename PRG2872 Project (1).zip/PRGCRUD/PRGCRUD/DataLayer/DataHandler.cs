﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using PRGCRUD.LogicLayer;
using PRGCRUD.PresentationLayer;

namespace PRGCRUD.DataLayer
{

    /*string name, surname, gender, phone, address, moduleCodes;
        int studentNum;
        DateTime dateOfBirth;
        */


    internal class DataHandler
    {
        static string connect = "Data Source=ASUS-ROG-RGB;Initial Catalog=prgDB;Integrated Security=SSPI";
        SqlConnection connection = new SqlConnection(connect);
        string query;
        SqlDataAdapter adapter;
        SqlCommand command;
        DataTable table;


        public bool ValidateLogin(string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();

               
                string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND Password = @Password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    int count = (int)command.ExecuteScalar();

                    return count > 0; 
                }
            }

        }


        public void InsertStudent(Student student)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    connection.Open();

                    string query = $"INSERT INTO Student VALUES " +
                        $"('{student.StudentNumber}', '{student.StudentName}', '{student.StudentSurname}', " +
                        $"'{student.StudentImage}', '{student.DateOfBirth.ToString("yyyy-MM-dd")}', '{student.Gender}', " +
                        $"'{student.Phone}', '{student.Address}', '{student.ModuleCodes}')";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                // Handle the exception, log it, or throw it further if needed
                throw new Exception($"Error inserting student: {e.Message}");
            }
        }


        public void register(Student student)
        {
            query = $"INSERT INTO Student VALUES ('{student.StudentNum}','{student.Name}','{student.Surname}'," +
                $"'{student.Phone}','{student.Address}','{student.Pic}','{student.ModuleCodes}','{student.DateOfBirth}')";


            try
            {
                using (connection = new SqlConnection(connect))
                {
                    using (command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }
        }

        public void DeleteStudent(int studentNumber)
        {
            using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();

                string query = "DELETE FROM Student WHERE StudentNumber = @StudentNumber";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@StudentNumber", studentNumber);

                    // Execute the query
                    command.ExecuteNonQuery();
                }
            }
        }

        public DataTable Search(int studentnumber)
        {

            query = $"SELECT * FROM Student WHERE studentNumber = '{studentnumber}'";
            adapter = new SqlDataAdapter(query, connect);
            table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        


        public void updateStudentInfor(Student student)
        {
            query = $"UPDATE Student SET StudentNumber = '{student.StudentNum}',StudentName = '{student.Name}',StudentSurname = '{student.Surname}'," +
                $"Phone ='{student.Phone}',StudentAddress ='{student.Address}',ImagePath = '{student.Pic}',DOB = '{student.DateOfBirth}'" +
                $"WHERE studentNumber = '{student.StudentNum}'";

            try
            {
                using (connection = new SqlConnection(connect))
                {
                    command = new SqlCommand(query, connection);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                /*throw;*/
            }
        }


        public DataTable display()
        {
            query = @"SELECT * FROM Student";
            adapter = new SqlDataAdapter(query, connect);
            table = new DataTable();
            adapter.Fill(table);
            return table;
        }


        public void UpdateStudent(Student student)
        {
            /*using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();

                string query = "UPDATE Student SET Name = @Name, Surname = @Surname WHERE StudentNumber = @StudentNumber";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    
                    command.Parameters.AddWithValue("@Name", student.Name);
                    command.Parameters.AddWithValue("@Surname", student.Surname);
                    command.Parameters.AddWithValue("@StudentNumber", student.StudentNumber);

                    
                    command.ExecuteNonQuery();


                }

                connection.Close();
            }*/

            query = $"UPDATE Student SET StudentNumber = '{student.StudentNum}',StudentName = '{student.Name}',StudentSurname = '{student.Surname}'," +
                $"Phone = '{student.Phone}'" +
                $"WHERE StudentNumber = '{student.StudentNum}'";

            try
            {
                using (connection = new SqlConnection(connect))
                {
                    command = new SqlCommand(query, connection);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                /*throw;*/
            }


        }


        public DataTable modules()
        {
            query = @"SELECT * FROM Modules";
            adapter = new SqlDataAdapter(query, connect);
            table = new DataTable();
            adapter.Fill(table);
            return table;
        }


    }
}
/*Error updating student: Invalid column name 'StudentNum'*/