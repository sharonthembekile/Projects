﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRGCRUD.PresentationLayer;
using PRGCRUD.DataLayer;
using PRGCRUD.LogicLayer;
using System.Data.SqlClient;
/*using System.Data;*/

namespace PRGCRUD
{
    public partial class Form1 : Form
    {

        DataHandler dataHandler = new DataHandler();    

        public Form1()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            crudForm crudeFrom = new crudForm();
            crudeFrom.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txbUsername.Text;
            string password = txbPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill in the correct information to login.", "Error", MessageBoxButtons.OK ,MessageBoxIcon.Error);
                
                return;
            }

            bool isValidLogin = dataHandler.ValidateLogin(username, password);


            if (isValidLogin)
            {
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
