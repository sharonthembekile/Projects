﻿using PRGCRUD.DataLayer;
using PRGCRUD.LogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using PRGCRUD.PresentationLayer;
using System.Reflection;

namespace PRGCRUD.PresentationLayer
{
    public partial class crudForm : Form
    {

        static string connect = "Data Source=ASUS-ROG-RGB;Initial Catalog=prgDB;Integrated Security=SSPI";
        DataHandler handler = new DataHandler();
        BindingSource bindingSource = new BindingSource();
        public crudForm()
        {
            InitializeComponent();
        }

        private void StudentData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the student number from the textbox
                string studentNumberText = txbDelete.Text;

                // Validate the input (you may want to add additional validation)
                if (string.IsNullOrEmpty(studentNumberText) || !int.TryParse(studentNumberText, out int studentNumber))
                {
                    MessageBox.Show("Please enter a valid student number to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Assuming StudentNumber is an int, modify the DeleteStudent method accordingly
                dataHandler.DeleteStudent(studentNumber);

                // Display a success message or update the UI as needed
                MessageBox.Show("Student deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Handle the exception, log it, or show an error message
                MessageBox.Show($"Error deleting student: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private int GetStudentIDToDelete()
        {
            throw new NotImplementedException();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.StudentData.DataSource = null;
            bindingSource.DataSource = null;
            bindingSource.DataSource = handler.Search(int.Parse(txbSearch.Text));
            StudentData.DataSource = bindingSource;
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                

                using (SqlConnection connection = new SqlConnection(connect))
                {
                    connection.Open();

                    
                    string query = "SELECT * FROM Student";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        System.Data.DataTable dataTable = new System.Data.DataTable();
                        adapter.Fill(dataTable);
                                                
                        StudentData.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        DataHandler dataHandler = new DataHandler();

        private void btnCreate_Click(object sender, EventArgs e)
        {


            try
            {
                
                string name = txbStudentName.Text;
                string surname = txbStudentSurname.Text;
                

                
                Student newStudent = new Student
                {
                    Name = name,
                    Surname = surname,
                    
                };

                
                dataHandler.InsertStudent(newStudent);

                
                MessageBox.Show("Student created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating student: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            
                try
                {
                    
                    string studentNumber = txbStudentNumber.Text;
                    string name = txbStudentName.Text;
                    string surname = txbStudentSurname.Text;
                    
                    Student updatedStudent = new Student
                    {
                        StudentNum = int.Parse(studentNumber),
                        Name = name,
                        Surname = surname,
                        
                    };

                    
                    dataHandler.UpdateStudent(updatedStudent);

                    
                    MessageBox.Show("Student updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error updating student: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModules_Click(object sender, EventArgs e)
        {
            try
            {


                using (SqlConnection connection = new SqlConnection(connect))
                {
                    connection.Open();


                    string query = "SELECT * FROM Modules";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        System.Data.DataTable dataTable = new System.Data.DataTable();
                        adapter.Fill(dataTable);

                        ModuleData.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}