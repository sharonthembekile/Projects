USE ProgrammingDB;
GO 

CREATE TABLE Users(
UserID INT PRIMARY KEY IDENTITY(1,1),
Username VARCHAR(50) NOT NULL,
Passwordd VARCHAR(50) NOT NULL,
ConfirmPassword VARCHAR(50) NOT NULL
);

CREATE TABLE Student(
StudentID INT PRIMARY KEY,
StudentNumber INT NOT NULL,
StudentName VARCHAR(50) NOT NULL,
StudentSurname VARCHAR(50) NOT NULL,
ImagePath VARCHAR(255),
DOB DATE,
Gender VARCHAR(10),
Phone VARCHAR(20),
StudentAddress VARCHAR(50),
ModuleCodes VARCHAR(255)
);

CREATE TABLE Modules (
ModuleID INT PRIMARY KEY IDENTITY(1,1),
ModuleCode VARCHAR(20) UNIQUE NOT NULL,
ModuleName VARCHAR(50) NOT NULL,
ModuleDescription VARCHAR(255),
OnlineResources VARCHAR(255)
);

INSERT INTO Users VALUES
('Vhugala', 'Tshishonga123', 'Tshishonga123');

INSERT INTO Student VALUES
(567, 'Thembi', 'Magalela', '"C:\Users\vhuga\Downloads\Thembi.jpg"', 2002-02-22, 'M', '0647894165', 'PTA Heatherdale', 'BCOMP1781'),
(546, 'Karabo', 'Linala', '"C:\Users\vhuga\Downloads\Karabo.jpg"', 2001-04-12, 'M', '0607898435', 'PTA Akasia', 'BCOMP1781'),
(526, 'Kamo', 'Mototo', '"C:\Users\vhuga\Downloads\Kamo.jpg"', 2004-07-17, 'M', '0797874165', 'PTA Sosha', 'BIT1781'),
(539, 'Tracy', 'Johnson', 'No Image available', 2004-07-17, 'M', '0667879065', 'PTA Karen1884', 'DIT161');

INSERT INTO Modules VALUES
('BCOMP1781', 'Bachelor of Computing', 'Bcomp leads yo uto various professional careers', 'https://youtu.be/k0GlqFrRQI0?si=MnSP7ta-M7dB1bz4'),
('DIT161', 'Diploma In IT', 'DIT provides students with a wide spectrum of dtudy covering the breath of IT', 'https://youtu.be/7WB86QFiwLg?si=aSyA5iv3UA-N1_S-'),
('BIT1781','Bachelor In IT','focuses on information systems modules and will provide you with foundational knowledge in software engineering', 'https://youtu.be/qPBSvlhe9v0?si=sV9YUZBUMaPu9PAh');