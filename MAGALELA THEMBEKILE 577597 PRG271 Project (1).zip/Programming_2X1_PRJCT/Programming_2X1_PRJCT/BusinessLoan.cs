﻿using System;
namespace Programming_2X1_PRJCT
{
    public class BusinessLoan : Loan
	{

        private double prime_Rating;
        private double InterestingRate;

        public BusinessLoan(string firstName, string lastName, decimal loanAmount, decimal interestRate, int loanNumber, int loanTerm, int shortTerm, int mediumTerm, int longTerm, string companyName, decimal maxLoanAmount, double prime_Rating ,double InterestingRate) : base(firstName, lastName, (double)loanAmount, (double)interestRate, loanNumber, loanTerm, shortTerm, mediumTerm, longTerm, companyName, maxLoanAmount)
        {

            this.prime_Rating = prime_Rating;
            this.InterestingRate = InterestingRate;
        }

        public override string InterestRating()
        {
            double calculatedInterestRate = prime_Rating + 0.01;
            return calculatedInterestRate.ToString();
        }

        public override string ToString()
        {
            return $"Business Loan - Name: {FirstName1} {LastName1}, Loan Amount: {LoanAmount1:C}, Interest Rate: {InterestRate1:P}, Loan Number: {LoanNumber1}, Loan Term: {LoanTerm1}";
        }
    }
}

