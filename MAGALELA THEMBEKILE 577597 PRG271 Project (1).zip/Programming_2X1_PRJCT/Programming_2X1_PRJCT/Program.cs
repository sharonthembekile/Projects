﻿using System;

namespace Programming_2X1_PRJCT
{
    class Program
    {
        private static decimal interestRate;
        private static int shortTerm;
        private static int loanNumber;
        private static double prime_Rating;
        private static decimal maxloanAmount;
        private static string companyName;
        private static int longTerm;
        private static int mediumTerm;

        public static double InterestingRate { get; private set; }

        static void Main(string[] args)
        {
            const int maxLoans = 5;
            Loan[] loans = new Loan[maxLoans];
            Console.WriteLine("Welcome to the ZEE Banking App");

            Console.WriteLine("Enter the current prime interest rate:");
            double primeInterestRate = Convert.ToDouble(Console.ReadLine());
            for (int i = 0; i < maxLoans; i++)
            {
                Console.WriteLine($"Loan {i + 1}");

                Console.Write("Enter loan type (B for Business, P for Personal): ");

                char loanType = Console.ReadLine().ToUpper()[0];

                Console.Write("Enter customer lastname: ");
                string lastName = Console.ReadLine();

                Console.Write("Enter customer firstname: ");
                string firstName = Console.ReadLine();

                Console.Write("Enter loan amount: ");
                double loanAmount = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter loan term (S for Short, M for Medium, L for Long): ");
                char loanTerm = Console.ReadLine().ToUpper()[0];

                Loan newLoan;

                if (loanType == 'B')
                {
                    newLoan = new BusinessLoan(firstName, lastName, (decimal)loanAmount, interestRate, loanNumber, loanTerm, shortTerm, mediumTerm, longTerm, companyName, maxloanAmount, prime_Rating, InterestingRate);
                }
                else if (loanType == 'P')
                {
                    newLoan = new PersonalLoan(firstName, lastName, (decimal)loanAmount, interestRate, loanNumber, loanTerm, shortTerm, mediumTerm, longTerm, companyName, maxloanAmount, prime_Rating, InterestingRate);
                }
                else
                {
                    Console.WriteLine("Invalid loan type. Skipping this loan.");
                    continue;
                }

                loans[i] = newLoan;
                Console.WriteLine("Loan added.\n");


                loans[i] = newLoan;
                Console.WriteLine("Loan added.\n");

                loans[i] = newLoan;
                Console.WriteLine("Loan added.\n");


                loans[i] = newLoan;
                Console.WriteLine("Loan added.\n");
                Console.WriteLine("Loan added.\n");
                Console.WriteLine("\nList of created loans:");
                foreach (Loan loan in loans)
                {
                    if (loan != null)
                    {
                        Console.WriteLine(loan);
                    }

                }
                Console.ReadLine();
            }
        }
    }
}

