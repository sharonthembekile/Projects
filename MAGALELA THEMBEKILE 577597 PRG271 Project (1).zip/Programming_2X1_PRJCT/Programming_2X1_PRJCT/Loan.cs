﻿using System;
namespace Programming_2X1_PRJCT
{
	public abstract class Loan :ILoanConstants
    {
        private string FirstName, LastName;
        private double LoanAmount, InterestRate;
        private int LoanNumber, LoanTerm;
        private int ShortTerm, MediumTerm, LongTerm;
        private string CompanyName;
        private decimal MaxLoanAmount;

        protected Loan(string firstName, string lastName, double loanAmount, double interestRate, int loanNumber, int loanTerm, int shortTerm, int mediumTerm, int longTerm, string companyName, decimal maxLoanAmount)
        {
            FirstName1 = firstName;
            LastName1 = lastName;
            LoanAmount1 = loanAmount;
            InterestRate1 = interestRate;
            LoanNumber1 = loanNumber;
            LoanTerm1 = loanTerm;
            ShortTerm1 = shortTerm;
            MediumTerm1 = mediumTerm;
            LongTerm1 = longTerm;
            CompanyName1 = companyName;
            MaxLoanAmount1 = maxLoanAmount;
        }

        public string FirstName1 { get => FirstName; set => FirstName = value; }
        public string LastName1 { get => LastName; set => LastName = value; }
        public double LoanAmount1 { get => LoanAmount; set => LoanAmount = value; }
        public double InterestRate1 { get => InterestRate; set => InterestRate = value; }
        public int LoanNumber1 { get => LoanNumber; set => LoanNumber = value; }
        public int LoanTerm1 { get => LoanTerm; set => LoanTerm = value; }
        public int ShortTerm1 { get => ShortTerm; set => ShortTerm = value; }
        public int MediumTerm1 { get => MediumTerm; set => MediumTerm = value; }
        public int LongTerm1 { get => LongTerm; set => LongTerm = value; }
        public string CompanyName1 { get => CompanyName; set => CompanyName = value; }
        public decimal MaxLoanAmount1 { get => MaxLoanAmount; set => MaxLoanAmount = value; }

        public abstract string InterestRating();

        public abstract override string ToString();
    }
}

