﻿using System;
namespace Programming_2X1_PRJCT
{
    public interface ILoanConstants 
	{

        int ShortTerm1 { get; }
        int MediumTerm1 { get; }
        int LongTerm1 { get; }
        string CompanyName1 { get; }
        decimal MaxLoanAmount1 { get; }
    }
}

